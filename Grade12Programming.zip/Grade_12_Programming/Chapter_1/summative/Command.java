package summative;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum Command {
	VIEW_FLEET(Arrays.asList("view fleet", "show fleet", "view buses", "show buses",
			"fleet", "buses", "view")),
	ADD_BUS(Arrays.asList("add bus", "add", "add new bus", "new bus")),
	REMOVE_BUS(Arrays.asList("remove bus", "delete bus", "remove", "delete")),
	EDIT_BUS(Arrays.asList("edit bus", "change bus", "edit")),
	COMMANDS(Arrays.asList("show commands", "commands", "view commands",
			"help")),
	EXIT(Arrays.asList("exit", "leave", "quit", "goodbye", "close")),
	INVALID(Collections.emptyList());
	
	private final List<String> invocations;
	
	Command(List<String> invocations) {
		this.invocations = invocations;
	}
	
	public static Command get(String invocation) {
		for (Command c : Command.values()) {
			for (String s : c.invocations()) {
				if (s.equalsIgnoreCase(invocation)) {
					return c;
				}
			}
		}
		return Command.INVALID;
	}
	
	public List<String> invocations() {
		return this.invocations;
	}
	
	@Override
	public String toString() {
		return ("\t- View Fleet\n\t- Add Bus\n\t- Remove Bus\n\t- Edit Bus\n\t- Exit");
	}
}
