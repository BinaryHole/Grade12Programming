package summative;

public class GpsCoordinate {
	private double latitude;
	private double longitude;
	
	public GpsCoordinate() {}
	
	public GpsCoordinate(double latitude, double longitude) {
		this.setLatitude(latitude);
		this.setLongitude(longitude);
	}
	
	public double getLatitude() {
		return latitude;
	}
	
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	
	public double getLongitude() {
		return longitude;
	}
	
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	
	public static double getDistanceBetween(GpsCoordinate c1, GpsCoordinate c2) {
		return(Math.sqrt((Math.pow(c1.getLatitude(), 2) + Math.pow(c2.getLatitude(), 2))
				+ (Math.pow(c1.getLongitude(), 2) + Math.pow(c2.getLongitude(), 2))));
	}
}
