package formative.atm;

public class Account {
	private String name;
	private String password;
	private double balance;
	private double interestRate;
	
	public Account() {}

	public Account(String name, String password, double balance, double interestRate) {
		this.setName(name);
		this.setPassword(password);
		this.setBalance(balance);
		this.setInterestRate(interestRate);
	}
	
	public Account(String name, String password) {
		this.setName(name);
		this.setPassword(password);
		this.setBalance(0);
		this.setInterestRate(0.002);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void increaseBalance(double increment) {
		this.balance += increment;
	}
	
	public void decreaseBalance(double decrement) {
		this.balance -= decrement;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	
	public boolean isValidCredentials(String password) {
		if (password.equals(this.getPassword())) {
			return true;
		} else {
			return false;
		}
	}
}
