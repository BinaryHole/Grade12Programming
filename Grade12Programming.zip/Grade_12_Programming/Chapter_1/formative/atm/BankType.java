package formative.atm;

public enum BankType {
	MARKS_BANK("Mark's Bank"),
	ROYAL_BANK_OF_CANADA("Royal Bank of Canada"),
	TD_CANADATRUST("TD Canadatrust"),
	SCOTIABANK("Scotiabank");
	
	private final String name;
	
	BankType(String name) {
		this.name = name;
	}
	
	public static BankType get(String name) {
		for (BankType b : BankType.values()) {
			if (b.name.equals(name)) {
				return b;
			}
		}
		return null;
	}
	
	@Override
	public String toString() {
		return this.name;
	}
}
