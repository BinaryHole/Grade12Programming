package formatives.star_pyramid;

import java.util.Scanner;

public class Interface {
	public static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("Welcome. How many triangle lines would you like?");
		int iterations = Integer.parseInt(scan.nextLine());
		printTriangle(iterations, true);
	}
	
	public static void printTriangle(int iterations, boolean isFirst) {
		for (int i = 1; i <= iterations; i++) {
			if (isFirst || i == 1 || i == iterations) {
				System.out.print("@");
			} else {
				System.out.print("*");
			}
		}
		
		System.out.println();
		if (iterations > 0) {
			printTriangle(iterations-1, false);
		}
	}
}
