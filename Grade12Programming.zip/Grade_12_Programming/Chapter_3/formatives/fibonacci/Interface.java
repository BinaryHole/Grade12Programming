package formatives.fibonacci;

import java.util.Scanner;

public class Interface {
	public static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("E N T E R   T H E   F I B O N A C C I  ...  How many iterations?");
		int iterations = Integer.parseInt(scan.nextLine());
		doFibonacci(iterations);
	}
	
	public static void doFibonacci(int iterations) {
		doFibonacci(iterations, 1, 0);
	}
	
	public static void doFibonacci(int iterations, int current, int previous) {
		System.out.println(current+previous);
		if (iterations > 1) {
			doFibonacci(iterations-1, current+previous, current);
		}
	}
}
