package formatives.string_pyramid;

import java.util.Scanner;

public class Interface {
	public static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("Welcome to the string pyramid: please enter a string:");
		String s = scan.nextLine();
		doStringPyramid(s);
	}

	public static void doStringPyramid(String s) {
		if (s.length() > 2) {
			System.out.println(s.substring(1, s.length()-1));
			doStringPyramid(s.substring(1, s.length()-1));
		}
	}
}
