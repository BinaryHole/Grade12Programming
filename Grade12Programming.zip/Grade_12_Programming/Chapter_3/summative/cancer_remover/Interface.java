package summative.cancer_remover;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import summative.cancer_remover.Objects.Report;
import summative.cancer_remover.Objects.Tissue;

public class Interface {
	public static String fileName = "tissue01.txt";
	public static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		// initialize and read the tissue from the file specified
		System.out.println("Initializing...");
		System.out.println("Reading File..." + "\n");
		Tissue tissue = Tissue.parseTissue(readFile(fileName));
		
		// print the tissue and it's report
		System.out.println(tissue.toString());
		Report tissueReport = examineTissue(tissue);
		System.out.println(tissueReport.toString() + "\n");
		
		if (tissueReport.isCancerous()) {
			// if the report shows that the tissue is cancerous, ask the user if they would like perform a treatment
			System.out.println("Cancer has been detected in the tissue. Would you like to perfrom a treatment?");
			boolean validEntry = true;
			do {
				String choice = scan.nextLine();
				
				if (choice.equalsIgnoreCase("yes") || choice.equalsIgnoreCase("y")) {
					validEntry = true;
					System.out.println("Performing cancer-removal operation...");
					performCancerTreatment(tissue);
					
					System.out.println("Operation Complete!");
				} else if (choice.equalsIgnoreCase("no") || choice.equalsIgnoreCase("n")) {
					validEntry = true;
					System.out.println("Cancelling...");
				} else {
					System.out.println("Please enter 'yes' or 'no':");
					validEntry = false;
				}
			} while (!validEntry);
		} else {
			// if the report shows no cancerous cells, do nothing
			System.out.println("No cancer cells found; The tissue is healthy!");
		}
	}

	/**
	 * Examines a tissue for cancer and creates a report
	 * @param tissue - the tissue to be examined
	 * @return Report - the report representing the tissue's health
	 */
	public static Report examineTissue(Tissue tissue) {
		return tissue.createReport();
	}

	/**
	 * Performs a recursive treatment on the tissue, removing the outermost layer of cancer in
	 * a cancer cluster each round. A report is printed after each round showing the updated
	 * tissue and it's health.
	 * 
	 * @param tissue - the tissue to be treated
	 */
	public static void performCancerTreatment(Tissue tissue) {
		// flag all cancerous cells in the tissue
		for (int x = 0; x < tissue.getCells().length; x++) {
			for (int y = 0; y < tissue.getCells()[0].length; y++) {
				// check if the cell needs to be flagged:
				if (shouldFlag(tissue, x, y)) {
					// flag the cell
					tissue.getCells()[x][y].flag();
				}
			}
		}
		
		// kill all flagged cells in the tissue
		for (int x = 0; x < tissue.getCells().length; x++) {
			for (int y = 0; y < tissue.getCells()[0].length; y++) {
				if(tissue.getCells()[x][y].isFlagged()) {
					tissue.getCells()[x][y].kill();
				}
			}
		}
		
		// display the new tissue and report
		System.out.println(tissue.toString());
		System.out.println(tissue.createReport().toString() + "\n");
		
		// recurse the method if the tissue is still cancerous
		if (tissue.createReport().isCancerous()) {
			// delay five seconds for the user to observe the treatment before beginning the next treatment
			try {
				TimeUnit.SECONDS.sleep(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			performCancerTreatment(tissue);
		}
	}

	/**
	 * Determines if a cell should be flagged based on it's health
	 * @param tissue - the tissue in which the cell is found
	 * @param x - the x-coordinate of the cell
	 * @param y - the y-coordinate of the cell
	 * @return A boolean representing if the cell should be flagged or not
	 */
	public static boolean shouldFlag(Tissue tissue, int x, int y) {
		//check if the cell is cancerous
		if (tissue.getCells()[x][y].isCancerous()) {
			
			// loop through each x-differential from the original cell (distance of 1)
			for (int dx = -1; dx <= 1; dx++) {
			
				// loop through each y-differential from the original cell (distance of 1)
				for (int dy = -1; dy <= 1; dy++) {

					// skip the center and corner surrounding cells
					if (!(dx == 0 && dy == 0) && !(Math.abs(dx) == 1 && Math.abs(dy) == 1)) {

						// if the surrounding cell being checked is not out of bounds
						if (!(x+dx > tissue.getCells().length-1 || x+dx < 0) && !(y+dy > tissue.getCells()[0].length-1 || y+dy < 0)) {

							// if the surrounding cell is not cancerous, flag the initial cell being checked 
							// (this will ensure that we only flag the outer-most cells in the cancer cluster)
							if (!tissue.getCells()[x+dx][y+dy].isCancerous()) {
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
	
	/**
	 * read a text file using a buffered reader
	 * @param fileName - the name of the file to read
	 * @return String - the composition of the file contents
	 */
	public static String readFile(String fileName) {
		String str = "";
		try(BufferedReader br = new BufferedReader(new FileReader(fileName))) {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    str = sb.toString();
		} catch (FileNotFoundException e) {
			System.out.println("File not found!");
			System.exit(0);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return str;
	}
}
