package io_testing;

import formative.atm.ATM;
import formative.atm.Account;
import formative.atm.BankType;

public class Test {

	public static void main(String[] args) {
		ATM a = ATM.readATM("output.txt");
		System.out.println("done");
		
//		ATM a = new ATM(BankType.MARKS_BANK, 2500);
//		a.addAccount(new Account("Mark", "1234"));
//		a.addAccount(new Account("Bob", "bobpass1"));
//		a.addAccount(new Account("Joe", "joethebest123"));
//		
//		a.writeATM("output.txt");
//		ATM.readATM("output.txt");
//		
//		System.out.println("done");
	}
}
