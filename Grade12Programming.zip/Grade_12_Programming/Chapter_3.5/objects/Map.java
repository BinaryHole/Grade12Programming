package objects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import objects.Tile.EntryType;

public class Map {
	private Tile[][] tiles;
	private Coordinate startingPositon;
	private Coordinate destinationPosition;
	private int runTimes = 0;
	
	// this list is used to store all possible routes, determine the best route, and show how many routes were found
	private List<Route> routes;

	public Map(Tile[][] tiles, Coordinate startingPosition, Coordinate destinationPosition) {
		this.setTiles(tiles);
		this.setStartingPositon(startingPosition);
		this.setDestinationPosition(destinationPosition);
	}

	public Tile[][] getTiles() {
		return tiles;
	}

	public void setTiles(Tile[][] tiles) {
		this.tiles = tiles;
	}

	public Coordinate getStartingPositon() {
		return startingPositon;
	}

	public void setStartingPositon(Coordinate startingPositon) {
		this.startingPositon = startingPositon;
	}

	public Coordinate getDestinationPosition() {
		return destinationPosition;
	}

	public void setDestinationPosition(Coordinate destinationPosition) {
		this.destinationPosition = destinationPosition;
	}

	public List<Route> getRoutes() {
		return routes;
	}

	public void setRoutes(List<Route> routes) {
		this.routes = routes;
	}
	
	public void addRoute(Route route) {
		this.routes.add(route);
	}
	
	public Route getFastestRoute() {
		Route fastestRoute = null;
		
		// loop through each route in the route list
		for (Route r: getRoutes()) {
			// if this is the first route, set it to the fastest route
			if (fastestRoute == null) {
				fastestRoute = r;
				
			// if the discovered route is faster than the current fastes route, update
			} else if (r.getTravelTime() <= fastestRoute.getTravelTime()) {
				fastestRoute = r;
			}
		}
		
		return fastestRoute;
	}
	
	public void findPossibleRoutes() {
		// clear the list of routes in case this was previously run
		setRoutes(new ArrayList<>());
		
		// find all possible routes
		recurseFindRoutes(true);
	}
	
	private void recurseFindRoutes(boolean isStart) {
		if (isStart) {
			// TODO
			System.out.println("RECURSING FOR THE FIRST TIME");
			
			// create a new route that will be filled on the next recursion
			addRoute(new Route());
			
			// add the first move to mark the starting location
			getRoutes().get(getRoutes().size()-1).addMove(new Move(getStartingPositon(), getStartingPositon(), 0));
			
			// recurse using the method is isStart = false
			recurseFindRoutes(false);
		} else {
			// TODO
			System.out.println(String.format("RECURSING AGAIN! (#%s)", this.runTimes++));
			
			// find starting location from the previous move
			Coordinate currentPos = getRoutes().get(getRoutes().size()-1).getMoves().get(getRoutes().get(getRoutes().size()-1)
					.getMoves().size()-1).getTo();
			System.out.println(currentPos.toString());
			
			// if the current position is NOT the destination (IE: we need to keep going):
			if (!isDestination(currentPos)) {
				// try moving up
				if (isWithinBounds(new Coordinate(currentPos.getxValue(), currentPos.getyValue()+1))) {
					// if the tile up has not been visited already:
					if (!getRoutes().get(getRoutes().size()-1).hasVisited(new Coordinate(currentPos.getxValue(), currentPos.getyValue()+1))) {
						// add the up-move to the current route's moves
						getRoutes().get(getRoutes().size()-1).addMove(new Move(currentPos, new Coordinate(
								currentPos.getxValue(), currentPos.getyValue()+1), 
								getTiles()[currentPos.getxValueRaw()][currentPos.getyValueRaw()+1].getStopTimeNS()));
						
						// recurse again
						recurseFindRoutes(false);
					}
				}
				
				// try moving right
				if (isWithinBounds(new Coordinate(currentPos.getxValue()+1, currentPos.getyValue()))) {
					// if the tile right has not been visited already:
					if (!getRoutes().get(getRoutes().size()-1).hasVisited(new Coordinate(currentPos.getxValue()+1, currentPos.getyValue()))) {
						// add the right-move to the current route's moves
						getRoutes().get(getRoutes().size()-1).addMove(new Move(currentPos, new Coordinate(
								currentPos.getxValue()+1, currentPos.getyValue()), 
								getTiles()[currentPos.getxValueRaw()+1][currentPos.getyValueRaw()].getStopTimeEW()));
						
						// recurse again
						recurseFindRoutes(false);
					}
				}	
				
				// try moving down
				if (isWithinBounds(new Coordinate(currentPos.getxValue(), currentPos.getyValue()-1))) {
					// if the tile down has not been visited already:
					if (!getRoutes().get(getRoutes().size()-1).hasVisited(new Coordinate(currentPos.getxValue(), currentPos.getyValue()-1))) {
						// add the down-move to the current route's moves
						getRoutes().get(getRoutes().size()-1).addMove(new Move(currentPos, new Coordinate(
								currentPos.getxValue(), currentPos.getyValue()-1), 
								getTiles()[currentPos.getxValueRaw()][currentPos.getyValueRaw()-1].getStopTimeNS()));
						
						// recurse again
						recurseFindRoutes(false);
					}
				}
				
				// try moving left
				if (isWithinBounds(new Coordinate(currentPos.getxValue()-1, currentPos.getyValue()))) {
					// if the tile right has not been visited already:
					if (!getRoutes().get(getRoutes().size()-1).hasVisited(new Coordinate(currentPos.getxValue()-1, currentPos.getyValue()))) {
						// add the right-move to the current route's moves
						getRoutes().get(getRoutes().size()-1).addMove(new Move(currentPos, new Coordinate(
								currentPos.getxValue()-1, currentPos.getyValue()), 
								getTiles()[currentPos.getxValueRaw()-1][currentPos.getyValueRaw()].getStopTimeEW()));
						
						// recurse again
						recurseFindRoutes(false);
					}
				}
				
				// at this point, all possible moves have been exhausted without finding the destination,
				// we may now start a new route
				addRoute(getRoutes().get(getRoutes().size()-1));
				
			
			// if the current position IS the destination (IE: we can stop recursing now):
			} else {
				System.out.println("FOUND DESTINATION ***************");
				// save this route by creating a new route in the route list
				addRoute(getRoutes().get(getRoutes().size()-1));
			}
		}
	}
	
	/**
	 * Checks if the given coordinate is within the map's boundaries
	 * @param coordinate - the coordinate to be examined
	 * @return boolean
	 */
	public boolean isWithinBounds(Coordinate coordinate) {
		// if both x and y values are not out of the map's boundaries:
		if (coordinate.getxValueRaw() >= 0 && coordinate.getxValueRaw() <= getTiles().length-1
				&& coordinate.getyValueRaw() >= 0 && coordinate.getyValueRaw() <= getTiles()[0].length-1) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isDestination(Coordinate coordinate) {
		if (getDestinationPosition().getxValue() == coordinate.getxValue()
				&& getDestinationPosition().getyValue() == coordinate.getyValue()) {
			return true;
		} else {
			return false;
		}
	}

	public static Map parseMap(String input) {
		List<String> inputs = Arrays.asList(input.split(System.getProperty("line.separator")));

		// set the map size and the starting, finishing destinations
		Tile[][] tiles = new Tile[10][10];
		Coordinate startingPosition = Coordinate.parseCoordinate(inputs.get(0));
		Coordinate destinationPosition = Coordinate.parseCoordinate(inputs.get(1));

		// loop through each line in the input file
		for (int i = 2; i < 402; i += 4) {
			Tile newTile = new Tile();

			// if the intersection is a traffic light;
			if (inputs.get(i).equals("1")) {
				// set the tile to the appropriate EntryType
				newTile.setEntryNS(EntryType.TRAFFIC_LIGHT);
				newTile.setEntryEW(EntryType.TRAFFIC_LIGHT);

				// get the stop percentages from the given input
				int stopPercentageNS = Integer.parseInt(inputs.get(i + 3));
				int stopPercentageEW = 100 - stopPercentageNS;

				// set the stop time using the appropriate percentages
				newTile.setStopTimeNS(newTile.getEntryNS().getTravelTime() * stopPercentageNS);
				newTile.setStopTimeEW(newTile.getEntryEW().getTravelTime() * stopPercentageEW);

				// if the intersection is not a traffic light:
			} else {
				// if the NS part of the intersection is a stop sign:
				if (inputs.get(i + 1).equals("1")) {
					newTile.setEntryNS(EntryType.STOP_SIGN);
				} else {
					// if the NS part is open:
					newTile.setEntryNS(EntryType.OPEN);
				}

				// if the EW part of the intersection is a stop sign:
				if (inputs.get(i + 2).equals("1")) {
					newTile.setEntryEW(EntryType.STOP_SIGN);
				} else {
					// if the EW part is open:
					newTile.setEntryEW(EntryType.OPEN);
				}
			}

			// some mathemagics to determine the x and y values of the iterator
			int xValue = ((i - 2) / 4) % 10;
			int yValue = (int) Math.floor(((i - 2) / 4) / 10);

			// set the coordinate of the new tile
			newTile.setCoordinate(new Coordinate(xValue + 1, yValue + 1));

			// add the new tile to the tiles array
			tiles[xValue][yValue] = newTile;
		}

		return new Map(tiles, startingPosition, destinationPosition);
	}

	@Override
	public String toString() {
		String returnString = "";

		for (int x = 0; x < 10; x++) {
			for (int y = 0; y < 10; y++) {
				returnString += getTiles()[x][y].toString() + " ";
			}
			returnString += "\n";
		}

		return returnString;
	}
}
