package formatives.quote_of_the_day;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Interface {

	public static void main(String[] args) {
		Quote quote = getQuote("quotes.txt");
		System.out.println("Quote of the day:\n" + "'" + quote.getText() + "' -" + quote.getAuthor());
	}
	
	public static Quote getQuote(String fileName) {
		try {
			String[] quotes = readFile(fileName).split(System.getProperty("line.separator"));
			return Quote.parseQuote(quotes[getRandomInt(quotes.length-1,1)]);
		} catch (IOException e) {
			System.out.println("you screwed up...");
			System.exit(1);
			return null;
		}
	}
	
	public static int getRandomInt(int max, int min) {
		return (int)(Math.random() * max + min);
	}

	public static String readFile(String fileName) throws IOException {
		if (!fileName.endsWith(".txt")) {
			throw new InvalidFileExtensionException("Filename must end with '.txt'");
		}
		
		BufferedReader br = new BufferedReader(new FileReader(fileName));
	    StringBuilder sb = new StringBuilder();
	    String line = br.readLine();

	    while (line != null) {
	        sb.append(line);
	        sb.append(System.lineSeparator());
	        line = br.readLine();
	    }
	    
	    br.close();
	    
	    if (sb.length() == 0) {
	    	throw new FileEmptyException("File does not contain anything!");
	    }
	    return sb.toString();
	}
}

@SuppressWarnings("serial")
class FileEmptyException extends IOException {
	public FileEmptyException(String message) {
		super(message);
	}
}

@SuppressWarnings("serial")
class InvalidFileExtensionException extends IOException {
	public InvalidFileExtensionException(String message) {
		super(message);
	}
}
