package summative.subscriber_manager.objects;

import java.util.Calendar;

public class Subscription {
	private Calendar startDate;
	private Calendar expirationDate;
	
	public Subscription() {}
	
	public Subscription(Calendar startDate, Calendar expirationDate) {
		this.setStartDate(startDate);
		this.setExpirationDate(expirationDate);
	}

	public Calendar getStartDate() {
		return startDate;
	}

	public void setStartDate(Calendar startDate) {
		this.startDate = startDate;
	}

	public Calendar getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Calendar expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	/**
	 * Check if the subscription is expired
	 * @return boolean representing if the subscription is expired.
	 */
	public boolean isExpired() {
		return(Calendar.getInstance().after(this.expirationDate));
	}
	
	@Override
	public String toString() {
		String r = (this.getStartDate().toInstant().toString() + ", " + this.getExpirationDate().toInstant().toString());
		return r;
	}
}
