package summative.subscriber_manager.objects;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum Command {
	VIEW_SUBSCRIBERS(Arrays.asList("view subscribers", "view", "view all", "view subs",
			"subs", "subscribers")),
	ADD_SUBSCRIBER(Arrays.asList("add subscriber", "add", "add sub", "new subscriber", "new sub", "new")),
	EDIT_SUBSCRIBER(Arrays.asList("edit subscriber", "edit", "edit sub")),
	REMOVE_SUBSCRIBER(Arrays.asList("remove subscriber", "remove sub", "remove", "delete subscriber",
			"delete sub", "delete")),
	COMMANDS(Arrays.asList("show commands", "commands", "view commands",
			"help")),
	EXIT(Arrays.asList("exit", "leave", "quit", "goodbye", "close")),
	INVALID(Collections.emptyList());
	
	private final List<String> invocations;
	
	Command(List<String> invocations) {
		this.invocations = invocations;
	}
	
	public static Command get(String invocation) {
		for (Command c : Command.values()) {
			for (String s : c.invocations()) {
				if (s.equalsIgnoreCase(invocation)) {
					return c;
				}
			}
		}
		return Command.INVALID;
	}
	
	public List<String> invocations() {
		return this.invocations;
	}
	
	@Override
	public String toString() {
		return ("\t- View Subscribers\n\t- Add Subscriber\n\t- Edit Subscriber\n\t"
				+ "- Commands\n\t- Exit");
	}
}
