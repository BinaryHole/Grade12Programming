package summative.subscriber_manager.objects;

public class Subscriber {
	private Name name;
	private Address address;
	private String email;
	private Subscription subscription;
	
	public Subscriber() {}
	
	public Subscriber(Name name, Address address, String email, Subscription subscription) {
		this.setName(name);
		this.setAddress(address);
		this.setEmail(email);
		this.setSubscription(subscription);
	}
	
	public Name getName() {
		return name;
	}
	
	public void setName(Name name) {
		this.name = name;
	}
	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Subscription getSubscription() {
		return subscription;
	}

	public void setSubscription(Subscription subscription) {
		this.subscription = subscription;
	}

	@Override
	public String toString() {
		return (getName().toString() + ", " + getEmail() + ", " + getAddress().toString() +
				", " + getSubscription().toString());
//		return "THIS WORKS!";
	}
}
