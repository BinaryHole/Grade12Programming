package summative.cancer_remover.Objects;

public class Tissue {
	private Cell[][] cells;
	
	public Tissue() {}
	
	public Tissue(Cell[][] cells) {
		this.setCells(cells);
	}
	
	public Cell[][] getCells() {
		return cells;
	}

	public void setCells(Cell[][] cells) {
		this.cells = cells;
	}
	
	public static Tissue parseTissue(String tissue) {
		int width = tissue.split(System.getProperty("line.separator"))[0].length();
		int height = tissue.split(System.getProperty("line.separator")).length;
		
		Cell[][] cells = new Cell[width][height];
		
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				cells[x][y] = Cell.parseCell(Character.toString((tissue.split(System.getProperty("line.separator"))[y].charAt(x))));
			}
		}
		
		return new Tissue(cells);
	}
	
	/**
	 * Creates a report of the tissue's health
	 * @return A report of the tissue's health
	 */
	public Report createReport() {
		Report report = new Report();
		Cell[][] cells = this.getCells();
		
		// loop through each cell in the cell array
		for (int x = 0; x < cells.length; x++) {
			for (int y = 0; y < cells[0].length; y++) {
				report.setTotalCells(report.getTotalCells()+1);
				
				if (cells[x][y].isCancerous()) {
					report.setCancerous(true);
					report.setCancerousCells(report.getCancerousCells()+1);
				} else {
					report.setHealthyCells(report.getHealthyCells()+1);
				}
			}
		}
		
		report.setHealthyPercent((Double.valueOf(report.getHealthyCells())/Double.valueOf(report.getTotalCells()))*100);
		
		return report;
	}
	
	@Override
	public String toString() {
		String string = "";
		int width = this.getCells().length;
		int height = this.getCells()[0].length;
		
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				string += this.getCells()[x][y].toString();
			}
			string += "\n";
		}
		
		return string;
	}
}
