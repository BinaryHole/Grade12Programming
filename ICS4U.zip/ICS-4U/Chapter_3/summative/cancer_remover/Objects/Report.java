package summative.cancer_remover.Objects;

public class Report {
	private boolean isCancerous;
	private int totalCells;
	private int healthyCells;
	private int cancerousCells;
	private double healthyPercent;
	
	public Report() {
		setCancerous(false);
		setTotalCells(0);
		setHealthyCells(0);
		setCancerousCells(0);
		setHealthyPercent(0);
	}
	
	public Report(boolean isCancerous, int totalCells, int healthyCells) {
		setCancerous(isCancerous);
		setTotalCells(totalCells);
		setHealthyCells(healthyCells);
		setCancerousCells(totalCells-healthyCells);
		if (totalCells == 0) {
			setHealthyPercent(0);
		} else {
			setHealthyPercent(healthyCells/totalCells);
		}
	}
	
	public boolean isCancerous() {
		return isCancerous;
	}
	
	public void setCancerous(boolean isCancerous) {
		this.isCancerous = isCancerous;
	}
	
	public int getTotalCells() {
		return totalCells;
	}
	
	public void setTotalCells(int totalCells) {
		this.totalCells = totalCells;
	}

	public int getHealthyCells() {
		return healthyCells;
	}

	public void setHealthyCells(int healthyCells) {
		this.healthyCells = healthyCells;
	}

	public int getCancerousCells() {
		return cancerousCells;
	}

	public void setCancerousCells(int cancerousCells) {
		this.cancerousCells = cancerousCells;
	}
	
	public double getHealthyPercent() {
		return Math.round(this.healthyPercent*100)/100;
	}
	
	public void setHealthyPercent(double healthyPercent) {
		this.healthyPercent = healthyPercent;
	}
	
	@Override
	public String toString() {
		return("REPORT:\n\tTotal Cells: " + this.getTotalCells() + 
				"\n\tHealthy Cells: " + this.getHealthyCells() +
				"\n\tCancerous Cells: " + this.getCancerousCells() +
				"\n\tHealthy Percentage: " + this.getHealthyPercent() + "%");
	}
}
