package objects;

public class Tile {
	private EntryType entryNS;
	private double stopTimeNS;
	private EntryType entryEW;
	private double stopTimeEW;
	private Coordinate coordinate;

	public Tile() {}
	
	public Tile(EntryType entryNS, int stopPercentageNS, EntryType entryEW, int stopPercentageEW) {
		this.setEntryNS(entryNS);		
		this.setEntryEW(entryEW);
		
		// actual entry times are determined by the stop percentage and the entry type
		this.setStopTimeNS(entryNS.getTravelTime()*stopPercentageNS);
		this.setStopTimeEW(entryEW.getTravelTime()*stopPercentageEW);
	}
	
	public EntryType getEntryNS() {
		return entryNS;
	}

	public void setEntryNS(EntryType entryNS) {
		this.entryNS = entryNS;
	}
	
	public double getStopTimeNS() {
		return stopTimeNS;
	}
	
	public void setStopTimeNS(double stopTimeNS) {
		this.stopTimeNS = stopTimeNS;
	}

	public EntryType getEntryEW() {
		return entryEW;
	}

	public void setEntryEW(EntryType entryEW) {
		this.entryEW = entryEW;
	}

	public double getStopTimeEW() {
		return stopTimeEW;
	}

	public void setStopTimeEW(double stopTimeEW) {
		this.stopTimeEW = stopTimeEW;
	}
	
	public Coordinate getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(Coordinate coordinate) {
		this.coordinate = coordinate;
	}

	public static Tile parseTile(String input) {
		
		return null;
	}
	
	@Override
	public String toString() {
		if (getEntryNS() == EntryType.OPEN && getEntryEW() == EntryType.OPEN) {
			return ("O");
		} else if (getEntryNS() == EntryType.OPEN && getEntryEW() == EntryType.STOP_SIGN) {
			return ("|");
		} else if (getEntryNS() == EntryType.STOP_SIGN && getEntryEW() == EntryType.OPEN) {
			return ("-");
		} else if (getEntryNS() == EntryType.TRAFFIC_LIGHT && getEntryEW() == EntryType.TRAFFIC_LIGHT) {
			return ("#");
		} else if (getEntryNS() == EntryType.STOP_SIGN && getEntryEW() == EntryType.STOP_SIGN) {
			return ("+");
		} else {
			return "?";
		}
	}

	public enum EntryType {
		STOP_SIGN(5),
		TRAFFIC_LIGHT(30),
		OPEN(2);
		
		private final int averageTravelTime;
		
		EntryType(int travelTime) {
			this.averageTravelTime = travelTime;
		}
		
		public int getTravelTime() {
			return this.averageTravelTime;
		}
	}
}
