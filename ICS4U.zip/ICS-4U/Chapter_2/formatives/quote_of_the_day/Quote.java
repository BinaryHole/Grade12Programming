package formatives.quote_of_the_day;

public class Quote {
	private String text;
	private String author;
	
	public Quote() {}
	
	public Quote(String text, String author) {
		this.setText(text);
		this.setAuthor(author);
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
	public static Quote parseQuote(String input) {
		return (new Quote(input.split("-")[0], input.split("-")[1]));
	}
}
