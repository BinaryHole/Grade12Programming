package summative.subscriber_manager.utilities;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Scanner;

import summative.subscriber_manager.objects.Address;
import summative.subscriber_manager.objects.Name;
import summative.subscriber_manager.objects.Subscriber;
import summative.subscriber_manager.objects.SubscriberCollection;
import summative.subscriber_manager.objects.Subscription;

public class outputTools {
	public static Scanner scan = new Scanner(System.in);
	public static String fileName = "magazine_sub_collection.txt";
	
	public static Calendar currentTime = Calendar.getInstance();
	public static Calendar expirationTime1 = currentTime;
	public static Calendar expirationTime2 = currentTime;
	
	public static Subscriber testSub1 = new Subscriber(new Name("Test", "One"), new Address(1, "Test Road", "Test City", "A1A1A1"),
			"test@gmail.com", new Subscription(currentTime, expirationTime1));
	public static Subscriber testSub2 = new Subscriber(new Name("Test", "Two"), new Address(2, "Test Street", "Test City",
			"A1A1A1"), "test2@yahoo.com", new Subscription(currentTime, expirationTime2));
	
	public static SubscriberCollection subs = new SubscriberCollection(Arrays.asList(testSub1, testSub2));
	
	public static void main(String[] args) {
		expirationTime1.add(Calendar.DAY_OF_YEAR, 1);
		expirationTime1.add(Calendar.DAY_OF_YEAR, -1);
		
		System.out.println("Would you like to do?");
		System.out.println("\t- Read file ('read')\n\t- Write file ('write')\n\t- Preview date string format ('date')"
				+ "\n\t- Preview subscriber format ('subscriber')");
		
		boolean validEntry = true;
		do {
			String userChoice = scan.nextLine();
			if (userChoice.equalsIgnoreCase("read")) {
				System.out.println("Reading file from '" + fileName +"'...\n");
				displaySubscribers(readFile());
			} else if (userChoice.equalsIgnoreCase("write")) {
				System.out.println("Writing file... to " + fileName);
				writeFile();
			} else if (userChoice.equalsIgnoreCase("date")) {
				System.out.println(testSub1.getSubscription());
			} else if (userChoice.equalsIgnoreCase("subscriber")) {
				System.out.println(testSub1.toString());
			}
		} while (!validEntry);
	}
	
	public static SubscriberCollection readFile() {
		return(SubscriberCollection.readSubscriberCollection(fileName));
	}
	
	public static void writeFile() {
		subs.writeSubscriberCollection(fileName);
		System.out.println("Completed successfully!");
	}
	
	public static void displaySubscribers(SubscriberCollection subs) {
		if (subs.size() == 0) {
			System.out.println("You have no subscribers listed!");
		} else {
			System.out.println("Listed Subscribers:");
			for (Subscriber s : subs.getSubscribers()) {
				System.out.println("\t" + s.getName().toString() + " | " + s.getEmail());
			}
		}
	}
}
