package summative.subscriber_manager.objects;

public class Address {
	private int residenceNumber;
	private String streetName;
	private String city;
	private String postalCode;
	
	public Address() {}
	
	public Address(int residenceNumber, String streetName, String city, String postalCode) {
		this.setResidenceNumber(residenceNumber);
		this.setStreetName(streetName);
		this.setCity(city);
		this.setPostalCode(postalCode);
	}
	
	public int getResidenceNumber() {
		return residenceNumber;
	}
	
	public void setResidenceNumber(int residenceNumber) {
		this.residenceNumber = residenceNumber;
	}
	
	public String getStreetName() {
		return streetName;
	}
	
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	
	public static boolean validPostalCode(String code) {
		if (code.length() == 6) {
			if (Character.isLetter(code.charAt(0)) &&
					Character.isLetter(code.charAt(2)) &&
					Character.isLetter(code.charAt(4)) &&
					Character.isDigit(code.charAt(1)) &&
					Character.isDigit(code.charAt(3)) &&
					Character.isDigit(code.charAt(5))
					) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	@Override
	public String toString() {
		return (this.getResidenceNumber() + " " + this.getStreetName() + ", " + this.getCity()
			+ ", " + this.getPostalCode());
	}
}
