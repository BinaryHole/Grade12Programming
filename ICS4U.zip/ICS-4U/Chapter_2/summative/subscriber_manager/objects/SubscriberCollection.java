package summative.subscriber_manager.objects;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

public class SubscriberCollection {
	private List<Subscriber> subscribers;
	
	public SubscriberCollection() {
		this.setSubscribers(new ArrayList<>());
	}
	
	public SubscriberCollection(List<Subscriber> subscribers) {
		this.setSubscribers(subscribers);
	}

	public List<Subscriber> getSubscribers() {
		return subscribers;
	}

	public void setSubscribers(List<Subscriber> subscribers) {
		this.subscribers = subscribers;
	}
	
	public void addSubscriber(Subscriber sub) {
		this.subscribers.add(sub);
	}
	
	public void removeSubscriber(Subscriber sub) {
		this.subscribers.remove(sub);
	}
	
	public List<Subscriber> search(String searchTerm) {
		List<Subscriber> result = new ArrayList<>();
		
		for(Subscriber s : this.getSubscribers()) {
			if (s.toString().contains(searchTerm)) {
				result.add(s);
			}
		}
		
		return result;
	}
	
	public Subscriber findSubscriber(Name name) {
		for (Subscriber sub : this.getSubscribers()) {
			if (sub.getName().equals(name)) {
				return sub;
			}
		}
		return null;
	}
	
	public Subscriber findSubscriber(Address address) {
		for (Subscriber sub : this.getSubscribers()) {
			if (sub.getAddress().equals(address)) {
				return sub;
			}
		}
		return null;
	}
	
	public Subscriber findSubscriber(String email) {
		for (Subscriber sub : this.getSubscribers()) {
			if (sub.getEmail().equals(email)) {
				return sub;
			}
		}
		return null;
	}
	
	public int size() {
		return this.subscribers.size();
	}
	
	public void writeSubscriberCollection(String fileName) {
		try {
			PrintWriter outputStream = new PrintWriter(fileName);
			
			// print all subscribers' information
			for (Subscriber s: this.getSubscribers()) {
				// print current subscriber's information
				outputStream.print(s.toString());
				
				// add a custom line break element if the current subscriber is not the last in the collection 
				if (this.getSubscribers().indexOf(s) < (this.getSubscribers().size()-1)) {
					outputStream.print("`");
				}
				
				outputStream.println();
			}
			
			outputStream.close();
		} catch (Exception e) {
			System.out.println("File not found to write!");
			e.printStackTrace();
		}
	}
	
	public static SubscriberCollection readSubscriberCollection(String fileName) {
		try {
			String str;
			
			// read the contents of the given file
			try(BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			    StringBuilder sb = new StringBuilder();
			    String line = br.readLine();

			    while (line != null) {
			        sb.append(line);
			        sb.append(System.lineSeparator());
			        line = br.readLine();
			    }
			    str = sb.toString();
			}
			
			SubscriberCollection subCollection = new SubscriberCollection();
			
			// read each subsriber's information
			for (String s : str.split("`")) {
				s = s.replace(System.getProperty("line.separator"), "");
				
				// get each subscriber element by it's position in the split string
				Name name = new Name(s.split(", ")[1], s.split(", ")[0]);
				String email = s.split(", ")[2];
				
				int streetNum = Integer.parseInt(s.split(", ")[3].split(" ")[0]);
				String streetName = s.split(", ")[3].replaceFirst(streetNum + " ", "");
				String city = s.split(", ")[4];
				String postalCode = s.split(", ")[5];
				
				Address address = new Address(streetNum, streetName, city, postalCode);
				
				Subscription subscription = new Subscription(GregorianCalendar.from(ZonedDateTime.from(Instant.parse(s.split(", ")[6]))),
						GregorianCalendar.from(ZonedDateTime.from(Instant.parse(s.split(", ")[7]))));
				
				// create and return the new subscriber with the extracted elements
				subCollection.addSubscriber(new Subscriber(name, address, email, subscription));
			}
			
			return subCollection;
		} catch (Exception e) {}
		
		return null;
	}
}
