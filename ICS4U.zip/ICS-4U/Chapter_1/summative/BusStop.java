package summative;

public class BusStop {
	private String name;
	private GpsCoordinate coordinate;
	
	public BusStop(String name, GpsCoordinate coordinate) {
		this.setName(name);
		this.setCoordinate(coordinate);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public GpsCoordinate getCoordinate() {
		return coordinate;
	}
	public void setCoordinate(GpsCoordinate coordinate) {
		this.coordinate = coordinate;
	}
}
