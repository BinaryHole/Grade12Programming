package summative;

import java.util.Arrays;
import java.util.List;

public class Bus {
	private String routeNumber;
	private Model model;
	private Status status = Status.AT_TERMINAL;
	private double currentGas = 0;
	private int currentPassengers = 0;
	private double currentSpeed = 0;
	private GpsCoordinate coordinates;
	
	public Bus() {}
	
	public Bus(String routeNumber, Model model, Status status, double currentGas, 
			int currentPassengers, double currentSpeed, GpsCoordinate coordinates) {
		this.routeNumber = routeNumber;
		this.model = model;
		this.status = status;
		this.currentGas = currentGas;
		this.currentPassengers = currentPassengers;
		this.currentSpeed = currentSpeed;
		this.coordinates = coordinates;
	}
	
	public String getRouteNumber() {
		return routeNumber;
	}
	
	public void setRouteNumber(String routeNumber) {
		this.routeNumber = routeNumber;
	}
	
	public Bus withRouteNumber(String routeNumber) {
		setRouteNumber(routeNumber);
		return this;
	}
	
	public Model getModel() {
		return model;
	}
	
	public void setModel(Model model) {
		this.model = model;
	}
	
	public Bus withModel(Model model) {
		setModel(model);
		return this;
	}
	
	public Status getStatus() {
		return status;
	}
	
	public void setStatus(Status status) {
		this.status = status;
	}
	
	public Bus withStatus(Status status) {
		setStatus(status);
		return this;
	}
	
	public double getCurrentGas() {
		return currentGas;
	}
	
	public void setCurrentGas(double currentGas) {
		this.currentGas = currentGas;
	}
	
	public Bus withCurrentGas(double currentGas) {
		setCurrentGas(currentGas);
		return this;
	}

	public int getCurrentPassengers() {
		return currentPassengers;
	}
	
	public void setCurrentPassengers(int currentPassengers) {
		this.currentPassengers = currentPassengers;
	}

	public Bus withCurrentPassengers(int currentPassengers) {
		setCurrentPassengers(currentPassengers);
		return this;
	}
	
	public void addPassengers(int difference) {
		this.currentPassengers += difference;
	}
	
	public void removePassengers(int difference) {
		this.currentPassengers -= difference;
	}
	
	public double getCurrentSpeed() {
		return currentSpeed;
	}
	
	public void setCurrentSpeed(double currentSpeed) {
		this.currentSpeed = currentSpeed;
	}
	
	public Bus withCurrentSpeed(double currentSpeed) {
		setCurrentSpeed(currentSpeed);
		return this;
	}
	
	public GpsCoordinate getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(GpsCoordinate coordinates) {
		this.coordinates = coordinates;
	}
	
	public Bus withCoordinates(GpsCoordinate coordinates) {
		setCoordinates(coordinates);
		return this;
	}

	public void accelerate(double difference) {
		this.currentSpeed += difference;
	}
	
	public void decelerate(double difference) {
		this.currentSpeed -= difference;
	}
	
	public double getTimeBetweenStops(BusStop a, BusStop b) {
		double distance = GpsCoordinate.getDistanceBetween(a.getCoordinate(), b.getCoordinate());
		return(this.getCurrentSpeed()/distance);
	}
	
	enum Status {
		ON_ROUTE("On Route"),
		IN_REPAIRS("In Repairs"),
		AT_TERMINAL("At Terminal");
		
		private final String stringValue;
		
		Status(String stringValue) {
			this.stringValue = stringValue;
		}
		
		@Override
		public String toString() {
			return(this.stringValue);
		}
	}
	
	enum Model {
		SHORT("Short Bus", Arrays.asList("short bus", "short", "small bus", "small")),
		REGULAR("Regular Bus", Arrays.asList("regular bus", "regular", "default bus",
				"default")),
		DOUBLE("Double-Decker Bus", Arrays.asList("double decker bus",
				"double bus", "double decker", "double", "double-decker bus", "double-decker"));
		
		private final String stringValue;
		private final List<String> names;
		
		Model(String stringValue, List<String> names) {
			this.stringValue = stringValue;
			this.names = names;
		}
		
		public static Model get(String name) {
			for (Model m : Model.values()) {
				for (String n : m.names) {
					if (n.equalsIgnoreCase(name)) {
						return m;
					}
				}
			}
			return null;
		}
		
		public List<String> names() {
			return this.names;
		}
		
		public String stringValue() {
			return this.stringValue;
		}
		
		@Override
		public String toString() {
			return(this.stringValue);
		}
	}
}
