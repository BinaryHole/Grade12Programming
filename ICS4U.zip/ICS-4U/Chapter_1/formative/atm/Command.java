package formative.atm;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum Command {
	DEPOSIT_MONEY(Arrays.asList("deposit", "deposit money")),
	WITHDRAW_MONEY(Arrays.asList("withdraw", "withdraw money")),
	VIEW_BALANCE(Arrays.asList("view", "view balance", "balance",
			"current balance", "view current balance")),
	ADD_DAILY_INTEREST(Arrays.asList("add daily interest", "daily interest",
			"add interest", "interest")),
	COMMANDS(Arrays.asList("show commands", "commands", "view commands",
			"help")),
	EXIT(Arrays.asList("exit", "leave", "quit", "goodbye", "close")),
	LOGOUT(Arrays.asList("logout", "sign out", "log off", "log off")),
	CREATE_ACCOUNT(Arrays.asList("create", "create account", "create new account",
			"new account", "new")),
	SIGN_IN(Arrays.asList("sign in", "login", "log in")),
	INVALID(Collections.emptyList());
	
	private final List<String> invocations;
	
	Command(List<String> invocations) {
		this.invocations = invocations;
	}
	
	public static Command get(String invocation) {
		for (Command c : Command.values()) {
			for (String s : c.invocations()) {
				if (s.equalsIgnoreCase(invocation)) {
					return c;
				}
			}
		}
		return Command.INVALID;
	}
	
	public List<String> invocations() {
		return this.invocations;
	}
	
	@Override
	public String toString() {
		return ("\t- Deposit Money\n\t- Withdraw Money\n\t"
				+ "- View Balance\n\t- Add Daily Interest\n\t"
				+ "- Show Commands\n\t- Logout\n\t- Exit");
	}
}
