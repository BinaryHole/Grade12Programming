package formative.dog;

public class Dog {
	private String name;
	private DogBreed breed;
	private int aggression, hunger;

	public Dog() {
		name = "Rufus Doe";
		aggression = 0;
		hunger = 0;
	}

	public Dog(String name, DogBreed breed, int agg, int hung) {
		this.setName(name);
		this.setBreed(breed);
		this.setAggression(agg);
		this.setHunger(hung);
	}

	public Dog(String name, DogBreed breed) {
		this.name = name;
		this.breed = breed;
		this.aggression = (int) (Math.random() * 10) + 1;
		this.hunger = (int) (Math.random() * 10) + 1;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public DogBreed getBreed() {
		return this.breed;
	}
	
	public void setBreed(DogBreed breed) {
		this.breed = breed;
	}

	public int getAggression() {
		return this.aggression;
	}
	
	public void setAggression(int aggression) {
		this.aggression = aggression;
	}
	
	public int getHunger() {
		return this.hunger;
	}
	
	public void setHunger(int hunger) {
		this.hunger = hunger;
	}
	
	public void barkFriendly() {
		System.out.println(this.getName() + ": Arf! Arf!");
	}

	public void barkAngry() {
		System.out.println(this.getName() + ": GRR! RRRFFF!");
	}

	public String toString() {
		String output = "Name: " + name + "\n";
		output += "Breed: " + breed + "\n";
		output += "Aggression: " + aggression + "\n";
		output += "Hunger: " + hunger;
		return output;
	}
}
