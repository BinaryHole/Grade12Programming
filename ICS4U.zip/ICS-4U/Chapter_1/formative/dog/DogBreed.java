package formative.dog;

public enum DogBreed {
	GERMAN_SHEPHERD("German Shepherd"),
	LABRADORE_RETRIEVER("Labradore Retriever"),
	GOLDEN_RETRIEVER("Golden Retriever"),
	BULLDOG("Bulldog"),
	POODLE("Poodle"),
	BOXER("Boxer"),
	BEAGLE("Beagle"),
	YORKSHIRE_TERRIER("Yorkshire Terrier"),
	DACHSHUND("Dachshund"),
	ROTTWEILER("Rottweiler"),
	CHIHUAHUA("Chihuahua"),
	SIBERIAN_HUSKY("Siberian Husky"),
	GREAT_DANE("Great Dane"),
	BORDER_COLLIE("Border Collie"),
	SHIH_TZU("Shih Tzu"),
	PUG("Pug");
	
	private final String name;
	
	DogBreed(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
}
