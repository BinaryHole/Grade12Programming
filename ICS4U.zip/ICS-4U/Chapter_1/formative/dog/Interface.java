package formative.dog;

public class Interface {
	public static void main(String[] args) {
		System.out.println("Two dogs will now meet.");
		
		Dog a = new Dog("Jethaniel", DogBreed.BOXER);
		Dog b = new Dog("Hoses", DogBreed.SIBERIAN_HUSKY);
		
		determineOutcome(a, b);
	}
	
	public static void determineOutcome(Dog a, Dog b) {
		
		if (a.getAggression() == b.getAggression()) {
			// mate
			System.out.println(a.getName() + " and " + b.getName() + " have now mated!");
		} else if (a.getAggression() <= 5 && b.getAggression() <= 5) {
			if (a.getAggression() < b.getAggression()) {
				a.barkFriendly();
			} else {
				b.barkFriendly();
			}
		} else {
			if (a.getAggression() < b.getAggression()) {
				if (a.getHunger() >= 8) {
					// a eats b
					System.out.println(a.getName() + " has eaten " + b.getName());
				} else {
					a.barkAngry();
				}
			} else {
				if (b.getHunger() >= 8) {
					// b eats a
					System.out.println(b.getName() + " has eaten " + a.getName());
				} else {
					b.barkAngry();
				}
			}
		}
	}
}
