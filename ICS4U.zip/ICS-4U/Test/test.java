import java.util.Scanner;

public class test {
	
	public static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		for (int i = 2; i < 402; i+=4) {
			System.out.println(((i-2)/4)%10 + ", " + (((int) Math.floor(((i-2)/4)/10))));
		}
	}
}
