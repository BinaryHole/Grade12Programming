package testProject;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Calculator {

	public static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("====================" + " WELCOME TO: " + "====================\n"
				+ "=============" + " MARK'S INCREDIBLE MONTHLY " + "=============\n"
				+ "=============" + " TO HOURLY COST-CONVERTER! " + "=============");
		boolean successful = simpleMonthlyCostCalculator();
		if (successful) {
			System.out.println("Thank you for using the calculator!");
		} else {
			System.out.println("BOO, and error occured.");
		}
//		random();
	}

	public static boolean simpleMonthlyCostCalculator() {
		boolean userContinue = true;
		DecimalFormat f = new DecimalFormat("###,###,##0.000");
		do {
			System.out.print("Just enter a value: $");
			String input = scan.nextLine();
			if (input.equalsIgnoreCase("exit") || input.equalsIgnoreCase("e")) {
				userContinue = false;
			} else if (input.equalsIgnoreCase("restart") || input.equalsIgnoreCase("r")) {
				return simpleMonthlyCostCalculator();
			} else {
				try {
					double monthlyCost = Double.parseDouble(input);
					double hourlyCost = monthlyCost/30/24;
					System.out.println("SICK. Here's the conversion: $" + f.format(hourlyCost) + "\n");
				} catch (Exception e) {
					userContinue = false;
					return false;
				}
			}
		} while (userContinue);
		return true;
	}

	public static void random() {
		int x = 95;
		int y = 97;
		double z = Math.round((Double.valueOf(x)/Double.valueOf(y)*100));

		System.out.println("" + z);
	}
}

