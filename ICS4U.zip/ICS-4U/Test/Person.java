
public class Person {
	private String name;
	private int age;
	private boolean isAlive;
	
	public Person() {}
	
	public Person(String name) {
		this.name = name;
	}
	
	public Person(String name, int age, boolean isAlive) {
		this.name = name;
		this.age = age;
		this.isAlive = isAlive;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public boolean isAlive() {
		return this.isAlive;
	}
	
	public void setIsAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}
	
	public void sayName() {
		System.out.println("My name is " + getName());
	}
}
