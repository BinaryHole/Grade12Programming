package summative.cancer_remover.Objects;

public class Cell {
	public enum CellType {
		HEALTHY,
		CANCEROUS,
		DEAD
	}
	
	private CellType type;
	private boolean isFlagged;
	
	public Cell() {}

	public Cell(CellType type) {
		setType(type);
	}

	public boolean isCancerous() {
		return (getType() == CellType.CANCEROUS);
	}
	
	public boolean isFlagged() {
		return this.isFlagged;
	}
	
	public void flag() {
		this.isFlagged = true;
	}
	
	public void unFlag() {
		this.isFlagged = false;
	}
	
	public void kill() {
		setType(CellType.DEAD);
	}
	
	public CellType getType() {
		return this.type;
	}
	
	public void setType(CellType type) {
		this.type = type;
	}
	
	public static Cell parseCell(String cell) {
		if(cell.equals("+")) {
			return new Cell(CellType.HEALTHY);
		} else if (cell.equals("-")) {
			return new Cell(CellType.CANCEROUS);
		} else if (cell.equals(" ")) {
			return new Cell(CellType.DEAD);
		} else {
			return null;
		}
	}
	
	@Override
	public String toString() {
		if (getType().equals(CellType.DEAD)) {
			return " ";
		} else if (this.isFlagged) {
			return "O";
		} else if (getType().equals(CellType.CANCEROUS)) {
			return "-";
		} else if (getType().equals(CellType.HEALTHY)) {
			return "+";
		} else {
			return null;
		}
	}
}
