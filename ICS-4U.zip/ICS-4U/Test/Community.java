import java.util.List;

public class Community {
	private List<Person> people;
	private String language;
	
	public Community() {}
	
	public Community(List<Person> people, String language) {
		this.people = people;
		this.language = language;
	}
	
	public List<Person> getPeople() {
		return people;
	}
	public void setPeople(List<Person> people) {
		this.people = people;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	
	public Person findPerson(String name) {
		for (Person i : people) {
			if (i.getName().equalsIgnoreCase(name)) {
				return i;
			}
		}
		return null;
	}
}
