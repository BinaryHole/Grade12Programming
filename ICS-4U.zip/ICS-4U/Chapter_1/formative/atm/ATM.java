package formative.atm;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ATM {
	private List<Account> accounts;
	private double balance;
	private BankType bank;
	
	public ATM(BankType bank) {
		this.setAccounts(new ArrayList<>());
		this.setBalance(2000);
		this.setBank(bank);
	}
	
	public ATM(BankType bank, double balance) {
		this.setAccounts(new ArrayList<>());
		this.setBalance(balance);
		this.setBank(bank);
	}
	
	public ATM(List<Account> accounts, BankType bank) {
		this.setAccounts(accounts);
		this.setBalance(2000);
		this.setBank(bank);
	}
	
	public ATM(List<Account> accounts, double balance, BankType bank) {
		this.setAccounts(accounts);
		this.setBalance(balance);
		this.setBank(bank);
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	
	public void addAccount(Account account) {
		this.accounts.add(account);
	}
	
	public Account findAccount(String name) {
		for (Account a : this.getAccounts()) {
			if (a.getName().equals(name)) {
				return a;
			}
		}
		return null;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void increaseBalance(double increment) {
		this.balance += increment;
	}
	
	public void decreaseBalance(double decrement) {
		this.balance -= decrement;
	}

	public BankType getBank() {
		return bank;
	}

	public void setBank(BankType bank) {
		this.bank = bank;
	}
	
	public static ATM readATM(String fileName) {
		try {
			String str;
			try(BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			    StringBuilder sb = new StringBuilder();
			    String line = br.readLine();

			    while (line != null) {
			        sb.append(line);
			        sb.append(System.lineSeparator());
			        line = br.readLine();
			    }
			    str = sb.toString();
			}
			
			ATM atm = new ATM(BankType.get(str.split(System.getProperty("line.separator"))[0]));
			atm.setBalance(Double.parseDouble(str.split("~")[0].split(System.getProperty("line.separator"))[1]));
			
			for (String s : str.split("~")[1].split("@")) {
				s = s.replace(System.getProperty("line.separator"), "");

				String name = s.split(",")[0];
				String password = s.split(",")[1];
				Double balance = Double.parseDouble(s.split(",")[2]);
				Double interest = Double.parseDouble(s.split(",")[3]);
				
				Account a = new Account (name, password, balance, interest);
				
				atm.addAccount(a);
			}
			
			return atm;
		} catch (Exception e) {}
		
		return null;
	}
	
	public void writeATM(String fileName) {
		try {
			PrintWriter outputStream = new PrintWriter(fileName);
			outputStream.println(this.getBank().toString());
			outputStream.println(this.getBalance());
			outputStream.println("~");
			for (Account x : this.getAccounts()) {
				outputStream.print(x.getName() + "," + x.getPassword()
						+ "," + x.getBalance() + "," + x.getInterestRate());
				
				if (this.getAccounts().indexOf(x) < (this.getAccounts().size()-1)) {
					outputStream.print("@");
				}
				
				outputStream.println();
			}
			
			outputStream.close();
		} catch (Exception e) {
			System.out.println("File not found to write!");
		}
	}
}
