package formative.atm;

import java.util.Scanner;

public class Interface {

	public static Scanner scan = new Scanner(System.in);

	public static String saveFile = "output.txt";
	
	// In the real world, BankType would be predetermined, so it may be
	// changed here within the code since no outside information is received.
	public static ATM machine = ATM.readATM(saveFile);

	public static boolean userContinue = true;
	public static boolean isLoggedIn = false;
	
	// placeholder for the user's account they are logged in to
	public static Account userAccount = null;

	public static void main(String[] args) {
		
		System.out.println("Welcome to the digital ATM. This machine is"
				+ " operated by: " + machine.getBank());
		do {		
			System.out.println("\nYou are currently not logged in.");
			showLoginCommands();
			executeLoginOption(Command.get(scan.nextLine()));
			
			if (isLoggedIn) {
				System.out.println("\nWelcome," + userAccount.getName() + "!" +
						" What would you like to do today?");
				
				do {
					// display the available commands
					showCommands();
					
					// perform the user's desired command until they wish to quit
					executeCommand(Command.get(scan.nextLine()));
				} while (isLoggedIn);
			}
		} while (userContinue);
	}
	
	public static void showCommands() {
		System.out.println("Commands:\n" + Command.COMMANDS.toString());
	}
	
	public static void showLoginCommands() {
		System.out.println("Options:\n\t- Sign-in\n\t- Create New Account\n\t- Exit");
	}
	
	public static void createNewAccount() {
		System.out.println("\nNew Account:");
		
		boolean validEntry = true;
		String name;
		String password;
		
		do {
			System.out.println("Please choose a name for the new account:");
			name = scan.nextLine();
			
			if (name.isEmpty()) {
				System.out.println("Name cannot be blank.");
				validEntry = false;
			} else if (name.matches(".*\\d+.*")) {
				System.out.println("Name cannot contain numbers.");
				validEntry = false;
			} else {
				validEntry = true;
			}
		} while (!validEntry);
		
		do {
			System.out.println("Please choose a password for the new account:");
			password = scan.nextLine();
			
			if (password.isEmpty()) {
				System.out.println("Password cannot be blank.");
				validEntry = false;
			} else {
				System.out.println("New account created! You may now sign in.");
				validEntry = true;
				machine.addAccount(new Account(name, password));
			}
		} while (!validEntry);
		
	}
	
	public static void loginToExistingAccount() {
		System.out.println("Account Name:");
		String name = scan.nextLine();
		Account a = machine.findAccount(name);
		if (a == null) {
			System.out.println("Sorry, an account with that name could not be found.");
		} else {
			System.out.println("Password:");
			String password = scan.nextLine();
			
			if (a.isValidCredentials(password)) {
				System.out.println("Logging in...");
				userAccount = a;
				isLoggedIn = true;
			} else {
				System.out.println("Incorrect password.");
			}
		}
	}
	
	public static void executeCommand(Command command) {
		if (command.equals(Command.COMMANDS)) {
			showCommands();
		} else if (command.equals(Command.DEPOSIT_MONEY)) {
			depositMoney();
			saveMachine();
		} else if (command.equals(Command.WITHDRAW_MONEY)) {
			withdrawMoney();
			saveMachine();
		} else if (command.equals(Command.VIEW_BALANCE)) {
			viewBalance();
			saveMachine();
		} else if (command.equals(Command.ADD_DAILY_INTEREST)) {
			System.out.println("Sorry, this feature is not yet available.");
			// :)
		} else if (command.equals(Command.LOGOUT)) {
			System.out.println("Logging out...");
			isLoggedIn = false;
			userAccount = null;
			saveMachine();
		} else if (command.equals(Command.EXIT)) {
			System.out.println("Logging out...");
			isLoggedIn = false;
			userAccount = null;
			
			System.out.println("Quitting...");
			userContinue = false;
			saveMachine();
		}
	}
	
	public static void executeLoginOption(Command command) {
		if (command.equals(Command.CREATE_ACCOUNT)) {
			createNewAccount();
			saveMachine();
		} else if (command.equals(Command.SIGN_IN)) {
			loginToExistingAccount();
		} else if (command.equals(Command.INVALID)) {
			System.out.println("Invalid command.");
		} else if (command.equals(Command.EXIT)) {
			System.out.println("Quitting...");
			userContinue = false;
			saveMachine();
		}
	}
	
	public static void depositMoney() {
		System.out.println("Please insert deposit money into the machine:");
		// this is where the user would insert physical money, restricted by how much 
		// they have. Obviously, there is no physical correlation to the program, so the
		// user enters a value as a representative of real cash.
		
		boolean validBill = true;
		double depositAmount = 0;
		
		do {
			try {
				depositAmount = Double.parseDouble(scan.nextLine());
			} catch (Exception e) {
				System.out.println("Bill not recognized! Please try again.");
				validBill = false;
			}
		} while (!validBill);
		
		if (depositAmount != 0) {
			machine.increaseBalance(depositAmount);
			userAccount.increaseBalance(depositAmount);
			System.out.println("$" + depositAmount + " has been deposited to your account.");
		}
	}
	
	public static void withdrawMoney() {
		System.out.println("How much would you like to withdraw from your account?");
		
		boolean validAmount = true;
		double withdrawAmount = 0;
		
		do {
			try {
				withdrawAmount = Double.parseDouble(scan.nextLine());
				if (withdrawAmount > userAccount.getBalance()) {
					System.out.println("You do not have the sufficient funds in your account!");
				} else if (withdrawAmount > machine.getBalance()) {
					System.out.println("We're sorry, the machine cannot dispense that amount at this time.");
				}
			} catch (Exception e) {
				System.out.println("Please enter a dollar amount:");
				validAmount = false;
			}
		} while (!validAmount);
		
		if (withdrawAmount != 0) {
			machine.decreaseBalance(withdrawAmount);
			userAccount.decreaseBalance(withdrawAmount);
			System.out.println("Working...  \n\n*$" + withdrawAmount + " rolls out of the ATM*");
		}
	}
	
	public static void viewBalance() {
		System.out.println("You have $" + userAccount.getBalance() + " in your account.");
	}
	
	public static void saveMachine() {
		machine.writeATM(saveFile);
	}
}
