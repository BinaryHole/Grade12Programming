package summative;

import java.util.Scanner;

import summative.Bus.Model;

public class Interface {
	public static Scanner scan = new Scanner(System.in);
	public static boolean userContinue = true;
	
	public static Fleet fleet = new Fleet();
	
	public static void main(String[] args) {
		System.out.println("Welcome to the bus manager. Please choose a command:");
		do {
			showCommands();
			executeCommand(Command.get(scan.nextLine()));
		} while (userContinue);
	}
	
	public static void showCommands() {
		System.out.println("Commands: \n" + Command.COMMANDS.toString());
	}
	
	public static void displayFleet() {
		if (fleet.getBuses().size() == 0) {
			System.out.println("You have no buses in your fleet.");
		} else {
			System.out.println("Your fleet: ");
			for (Bus b : fleet.getBuses()) {
				System.out.println("\t" + b.getRouteNumber() + " - " + b.getStatus()
				+ " (" + b.getCoordinates().getLatitude() + ", " + b.getCoordinates().getLongitude() + ")");
			}
		}
	}
	
	public static void addBus() {
		System.out.println("New Bus:\nEnter bus type (short, regular, double):");
		boolean validEntry = true;
		Bus b = new Bus();
		
		do {
			Model model = Model.get(scan.nextLine());
			if (model == null) {
				System.out.println("Please enter a valid bus type:");
				validEntry = false;
			} else {
				b.setModel(model);
				validEntry = true;
			}
		} while (!validEntry);

		GpsCoordinate coordinate = new GpsCoordinate();
		
		System.out.println("Please enter starting latitude for the bus:");
		do {
			try {
				double latitude = Double.parseDouble(scan.nextLine());
				
				if (latitude > 100 || latitude < 0) {
					System.out.println("Please enter a number between 0-100:");
					validEntry = false;
				} else {
					coordinate.setLatitude(latitude);
					validEntry = true;
				}
			} catch (Exception e) {
				System.out.println("Please enter a valid number for latitude:");
				validEntry = false;
			}
		} while (!validEntry);
		
		System.out.println("Please enter starting longitude for the bus:");
		do {
			try {
				double longitude = Double.parseDouble(scan.nextLine());
				
				if (longitude > 100 || longitude < 0) {
					System.out.println("Please enter a number between 0-100:");
					validEntry = false;
				} else {
					coordinate.setLongitude(longitude);
					validEntry = true;
				}
			} catch (Exception e) {
				System.out.println("Please enter a valid number for longitude:");
				validEntry = false;
			}
		} while (!validEntry);

		String routeNumber = fleet.getLowestFreeRouteNumber();
		fleet.addBus(b.withRouteNumber(routeNumber).withCoordinates(coordinate));
		System.out.println("New " + b.getModel().stringValue() + " with route number " + routeNumber + " created!");
	}
	
	public static void removeBus() {
		System.out.println("Please enter the route number of the bus your wish to remove:");
		boolean validEntry = true;
		do {
			try {
				Bus b = fleet.findBus(scan.nextLine());
				
				if (b != null) {
					System.out.println("Are you sure you would like to remove bus " + b.getRouteNumber() + "?");
					String validation = scan.nextLine();
					
					if (validation.equalsIgnoreCase("yes") || validation.equalsIgnoreCase("y") ) {
						fleet.removeBus(b);
						System.out.println("Bus " + b.getRouteNumber() + " has been deleted.");
						validEntry = true;
					} else {
						System.out.println("Cancelling...");
						validEntry = true;
					}
				} else {
					System.out.println("Sorry, a bus with that route number could not be found!");
					validEntry = true;
				}
			} catch (Exception e) {
				System.out.println("Please enter a valid route number (4 digits):");
				validEntry = false;
			}
		} while (!validEntry);
	}
	
	public static void editBus() {
		System.out.println("Please enter the route number of the bus you wish to edit:");
		boolean validEntry = true;
		do {
			try {
				Bus b = fleet.findBus(scan.nextLine());
				
				if (b != null) {
					System.out.println("Bus " + b.getRouteNumber() + " found!");
					System.out.println("Enter new route number (leave blank to keep current):");
					do {
						String routeNumber = scan.nextLine();
						try {
							if (!routeNumber.equals("")) {
								b.setRouteNumber(Fleet.formatRouteNumber(Integer.parseInt(routeNumber)));
								validEntry = true;
							}
						} catch (Exception e) {
							System.out.println("Please enter a valid route number (4 digits)");
							validEntry = false;
						}
					} while (!validEntry);
					
					System.out.println("Enter new bus model, leave blank to keep current (short, regular, double):");
					do {
						try {
							Bus.Model model = Bus.Model.get(scan.nextLine());
							if (model != null) {
								b.setModel(model);
								validEntry = true;
							}
						} catch (Exception e) {
							System.out.println("Please enter a valid bus model:");
							validEntry = false;
						}
					} while (!validEntry);
				
				} else {
					System.out.println("Sorry, a bus with that route number could not be found!");
					validEntry = true;
				}
			} catch (Exception e) {
				System.out.println("Invalid Information entered! Please try again:");
				validEntry = false;
			}
		} while (!validEntry);
	}
	
	public static void executeCommand(Command command) {
		if (command.equals(Command.COMMANDS)) {
			showCommands();
		} else if (command.equals(Command.VIEW_FLEET)) {
			displayFleet();
		} else if (command.equals(Command.ADD_BUS)) {
			addBus();
		} else if (command.equals(Command.REMOVE_BUS)) {
			removeBus();
		} else if (command.equals(Command.EDIT_BUS)) {
			editBus();
		} else if (command.equals(Command.INVALID)) {
			System.out.println("Please enter a valid command:");
		} else if (command.equals(Command.EXIT)) {
			System.out.println("Quitting...");
			userContinue = false;
		}
	}
}
