package summative;

import java.util.ArrayList;
import java.util.List;

public class Fleet {
	private List<Bus> buses = new ArrayList<>();
	
	public Fleet() {}
	
	public Fleet(List<Bus> buses) {
		this.setBuses(buses);
	}
	
	public List<Bus> getBuses() {
		return buses;
	}

	public void setBuses(List<Bus> buses) {
		this.buses = buses;
	}
	
	public void addBus(Bus bus) {
		this.buses.add(bus);
	}
	
	public void removeBus(Bus bus) {
		this.buses.remove(bus);
	}
	
	public String getLowestFreeRouteNumber() {
		if (this.getBuses().size() == 0) {
			return formatRouteNumber(1);
		} else {
			for (int i = 1; i <= this.getBuses().size(); i++) {
				boolean routeNumberExists = false;
				for (Bus b : this.getBuses()) {
					if (Integer.parseInt(b.getRouteNumber()) == i) {
						routeNumberExists = true;
					}
				}
				
				if (!routeNumberExists) {
					return formatRouteNumber(i);
				}
			}
			return formatRouteNumber(this.getBuses().size() + 1);
		}
	}
	
	public Bus findBus(String routeNumber) {
		for (Bus b : this.getBuses()) {
			if (b.getRouteNumber().equals(routeNumber)) {
				return b;
			}
		}
		return null;
	}

	public static String formatRouteNumber(int number) {
		String n = String.valueOf(number);
		do {
			n = "0" + n;
		} while (n.length() < 4);
		return n;
	}
}
