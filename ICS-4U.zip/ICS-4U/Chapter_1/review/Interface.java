package review;
import java.util.Scanner;

public class Interface {
	public static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Welcome to the classroom manager.");
		System.out.println("Please select a command:\n" + "- Add Student\n" + "- Remove Student\n"
				+ "- Edit Student\n"+ "- View Class\n" + "- View Class Median\n" + "- View Highest-Grade Student\n"
				+ "- View Lowest-Grade Student\n" + "- Commands\n" + "- Exit\n");
		
		boolean userContinue = true;
		Class class1 = new Class();
		
		// Execute the user's desired commands until they wish to exit
		do { 	
			Class.Command command = Class.Command.get(scan.nextLine());
			if (command.equals(Class.Command.EXIT)) {
				System.out.println("Quitting...");
				userContinue = false;
			} else {
				// Execute the user's desired command
				class1.executeCommand(command);
				System.out.println();
			}
		} while (userContinue);
	}
}
