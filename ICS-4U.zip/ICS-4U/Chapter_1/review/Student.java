package review;

public class Student {
	private String name;
	private double grade;

	public Student() {
	}

	public Student(String name, double grade) {
		this.setGrade(Math.round(grade * 100) / 100);
		this.setName(name);
	}

	public Student(String name) {
		this.setName(name);
	}

	public double getGrade() {
		return grade;
	}

	public void setGrade(double grade) {
		this.grade = (Math.round(grade * 100) / 100);
	}

	public Student withGrade(double grade) {
		setGrade(Math.round(grade * 100) / 100);
		return this;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Student withName(String name) {
		setName(name);
		return this;
	}

	@Override
	public String toString() {
		return ("Name: " + this.getName() + "\tGrade: " + this.getGrade() + "%");
	}
}
