package review;
import java.util.*;

public class Class {
	public static Scanner scan = new Scanner(System.in);

	/**
	 * The possible commands that a user may enter
	 * 
	 * @param List Invocation - the invocations 
	 * @author mark
	 *
	 */
	public enum Command {
		COMMANDS(Arrays.asList("commands", "command list")),
		ADD_STUDENT(Arrays.asList("add student", "add")),
		REMOVE_STUDENT(Arrays.asList("remove student", "remove")),
		EDIT_STUDENT(Arrays.asList("edit student", "edit")),
		VIEW_CLASS(Arrays.asList("view class", "view", "show class")),
		VIEW_CLASS_MEDIAN(Arrays.asList("view class median", "class median", "median",
				"view class average","class average", "average")),
		VIEW_HIGHEST_GRADE(Arrays.asList("view highest grade", "view highest",
				"highest grade","highest", "show highest grade","show highest")),
		VIEW_LOWEST_GRADE(Arrays.asList("view lowest grade", "view lowest","lowest grade",
				"lowest", "show lowest grade","show lowest")),
		EXIT(Arrays.asList("exit", "leave","quit")),
		INVALID(Collections.emptyList());

		private final List<String> invocations;

		Command(List<String> invocations) {
			this.invocations = invocations;
		}

		// finds command given an invocation by the user
		public static Command get(String invocation) {
			for (Command c : Command.values()) {
				for (String s : c.invocations) {
					if (invocation.equalsIgnoreCase(s)) {
						return c;
					}
				}
			}
			return Command.INVALID;
		}

		public List<String> invocations() {
			return this.invocations;
		}
	}

	private List<Student> students = new ArrayList<>();

	public Class() {
	}

	public Class(List<Student> students) {
		this.students = students;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	public Class withStudents(List<Student> students) {
		setStudents(students);
		return this;
	}

	public void addStudent(Student student) {
		this.students.add(student);
	}

	public void removeStudent(Student student) {
		this.students.remove(student);
	}

	public Student findStudent(String name) {
		for (Student s : this.getStudents()) {
			if (s.getName().equalsIgnoreCase(name)) {
				return s;
			}
		}
		return null;
	}

	public List<Student> getHighestGrade() {
		ArrayList<Student> list = new ArrayList<>();
		for (Student s : this.getStudents()) {
			if (list.isEmpty()) {
				list.add(s);
			} else {
				if (list.get(0).getGrade() < s.getGrade()) {
					list = new ArrayList<>();
					list.add(s);
				} else if (list.get(0).getGrade() == s.getGrade()) {
					list.add(s);
				}
			}
		}
		return list;
	}

	public List<Student> getLowestGrade() {
		ArrayList<Student> list = new ArrayList<>();
		for (Student s : this.getStudents()) {
			if (list.isEmpty()) {
				list.add(s);
			} else {
				if (list.get(0).getGrade() > s.getGrade()) {
					list = new ArrayList<>();
					list.add(s);
				} else if (list.get(0).getGrade() == s.getGrade()) {
					list.add(s);
				}
			}
		}
		return list;
	}

	public double getClassMedian() {
		double average = 0;

		for (Student s : this.getStudents()) {
			average += s.getGrade();
		}

		average = average / this.getStudents().size();
		return average;
	}

	/**
	 * Prints the full class with each student and their grade.
	 * <p>Example: 
	 * 
	 */
	public void printClass() {
		if (this.students.size() == 0) {
			System.out.println("You have no students in your class.");
		} else {
			System.out.println(this.toString());
		}
	}

	@Override
	public String toString() {
		String output = "Your Class:\n";

		for (Student s : this.getStudents()) {
			output += "\t" + s.toString() + "\n";
		}

		return output;
	}

	/**
	 * Executes the user's desired command on the class by relevance to the Command enumerator
	 * @param c - the Command which the user desires to execute
	 */
	public void executeCommand(Command c) {
		if (c.equals(Class.Command.COMMANDS)) {
			System.out.println("- Add Student\n" + "- Remove Student\n" + "- Edit Student\n" + "- View Class\n"
					+ "- View Class Median\n" + "- View Highest-Grade Student\n" + "- View Lowest-Grade Student\n"
					+ "- Commands\n" + "- Exit\n");

		} else if (c.equals(Class.Command.ADD_STUDENT)) {
			System.out.println("\nAdd student:\nPlease enter the student's name:");
			String name = scan.nextLine();

			System.out.println("Enter the student's grade (optional):");
			String grade = scan.nextLine();

			Student newStudent = new Student(name);
			if (!grade.equals("")) {
				try {
					if (Double.parseDouble(grade) <= 100 && Double.parseDouble(grade) >= 0) {
						newStudent.setGrade(Double.parseDouble(grade));
						
						this.addStudent(newStudent);
						System.out.println("Student Added!");
					} else if (Double.parseDouble(grade) > 100) {
						System.out.println("Grade too large! (Cannot exceed 100)");
					} else if (Double.parseDouble(grade) < 0) {
						System.out.println("Grade too small! (Cannot be negative)");
					}
				} catch (Exception e) {
					System.out.println("Invalid Grade! (Please enter a percentage from 0-100)");
				}
			}


		} else if (c.equals(Class.Command.REMOVE_STUDENT)) {
			System.out.println("Remove student:\n" + "Enter the name of the student you wish to remove:");
			String name = scan.nextLine();

			Student s = this.findStudent(name);
			if (s == null) {
				System.out.println("Student not found!");
			} else {
				System.out.println("Student found: " + s.getName() + ". Are you SURE you wish to delete? (Y/N)");
				String choice = scan.nextLine();

				if (choice.equalsIgnoreCase("y") || choice.equalsIgnoreCase("yes")) {
					this.removeStudent(s);
					System.out.println("Student Removed!");
				} else if (choice.equalsIgnoreCase("n") || choice.equalsIgnoreCase("no")) {
					System.out.println("Aborting.");
				}
			}

		} else if (c.equals(Class.Command.EDIT_STUDENT)) {
			System.out.println("Edit student:\n" + "Enter the name of the student you wish to edit:");
			String name = scan.nextLine();

			Student s = this.findStudent(name);
			if (s == null) {
				System.out.println("Student not found!");
			} else {
				System.out.println("Enter new name: (leave blank to keep as '" + s.getName() + "')");
				String newName = scan.nextLine();

				if (!newName.equals("")) {
					s.setName(newName);
					System.out.print("Name Changed! ");
				}

				System.out.println("Enter a new grade: (leave blank to keep as " + s.getGrade() + "%)");
				String newGrade = scan.nextLine();

				if (!newGrade.equals("")) {
					s.setGrade(Double.parseDouble(newGrade));
					System.out.println("Grade Changed!");
				}
			}

		} else if (c.equals(Class.Command.VIEW_CLASS)) {
			this.printClass(); // so clean :)

		} else if (c.equals(Class.Command.VIEW_CLASS_MEDIAN)) {
			if (this.getStudents().size() == 0) {
				System.out.println("You have no students in your class.");
			} else {
				System.out.println(
						"Class average of " + this.getStudents().size() + " students: " + this.getClassMedian() + "%");
			}

		} else if (c.equals(Class.Command.VIEW_HIGHEST_GRADE)) {
			if (this.getStudents().size() == 0) {
				System.out.println("You have no students in your class.");
			} else {
				System.out.println("Highest Grade Student(s):");
				for (Student s : this.getHighestGrade()) {
					System.out.println(s.toString());
				}
			}

		} else if (c.equals(Class.Command.VIEW_LOWEST_GRADE)) {
			if (this.getStudents().size() == 0) {
				System.out.println("You have no students in your class.");
			} else {
				System.out.println("Lowest Grade Student(s):");
				for (Student s : this.getLowestGrade()) {
					System.out.println(s.toString());
				}
			}

		} else if (c.equals(Class.Command.INVALID)) {
			System.out.println("Invalid command entry! (type 'commands' for a list of commands)");
		}
	}
}
