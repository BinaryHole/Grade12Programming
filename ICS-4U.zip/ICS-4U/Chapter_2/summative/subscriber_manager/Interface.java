package summative.subscriber_manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import summative.subscriber_manager.objects.Address;
import summative.subscriber_manager.objects.Command;
import summative.subscriber_manager.objects.Name;
import summative.subscriber_manager.objects.Subscriber;
import summative.subscriber_manager.objects.SubscriberCollection;

public class Interface {
	public static Scanner scan = new Scanner(System.in);
	public static boolean userContinue = true;
	public static String fileName = "magazine_sub_collection.txt";
	public static SubscriberCollection subCollection = SubscriberCollection.readSubscriberCollection(fileName);
	
	public static void main(String[] args) {
		System.out.println("Welcome to the magazine subscriber manager! What would you like to do?\n"
				+ Command.COMMANDS.toString());
		
		do {
			// execute the user's desired command
			executeCommand(Command.get(scan.nextLine()));
			
			// save the file
			saveFile();
		} while (userContinue);
	}
	
	public static void executeCommand(Command command) {
		if (command.equals(Command.ADD_SUBSCRIBER)) {
			addSubscriber();
		} else if (command.equals(Command.EDIT_SUBSCRIBER)) {
			editSubscriber();
		} else if (command.equals(Command.REMOVE_SUBSCRIBER)) {
			removeSubscriber();
		} else if (command.equals(Command.VIEW_SUBSCRIBERS)) {
			displaySubscribers();
		} else if (command.equals(Command.COMMANDS)) {
			System.out.println(Command.COMMANDS.toString());
		} else if (command.equals(Command.EXIT)) {
			System.out.println("Quitting...");
			userContinue = false;
		} else if (command.equals(Command.INVALID)) {
			System.out.println("Invalid Command. (type 'commands' to view command list)");
		}
	}
	
	public static void displaySubscribers() {
		if (subCollection.size() == 0) {
			System.out.println("You have no subscribers listed!");
		} else {
			System.out.println("Listed Subscribers:");
			for (Subscriber s : subCollection.getSubscribers()) {
				System.out.println("\t" + s.getName().toString() + " | " + s.getEmail());
			}
		}
	}
	
	public static void addSubscriber() {
		System.out.println("New subscriber: ");
		Subscriber newSub = new Subscriber();
		boolean validEntry = true;
		
		do {
			System.out.println("Enter the name of the new subscriber ('first', 'last'): ");
			String name = scan.nextLine();
			
			if (name.isEmpty()) {
				System.out.println("Name cannot be blank.");
				validEntry = false;
			} else if (!name.replace(" ", "").matches("[a-zA-Z]+")) {
				System.out.println("Name must only be letters!");
				validEntry = false;
			} else if (!name.contains(" ")) {
				System.out.println("Please enter a first and last name: ");
				validEntry = false;
			} else {
				newSub.setName(new Name(name.split(" ")[0], name.split(" ")[1]));
				validEntry = true;
			}
		} while (!validEntry);
		
		do {
			System.out.println("Enter the email of the new subscriber:");
			String email = scan.nextLine();
			
			if (!email.contains("@") || !(email.contains(".com") || email.contains(".ca"))) {
				System.out.println("Please enter a valid email:");
				validEntry = false;
			} else {
				newSub.setEmail(email);
				validEntry = true;
			}
		} while (!validEntry);
		
		Address address = new Address();
		do {
			System.out.println("Enter the street number of the new subsciber's address:");
			String streetNum = scan.nextLine();
			
			if (streetNum.length() < 1 || streetNum.length() > 4) {
				System.out.println("Invalid size; please enter a street number from 1-4 digits:");
				validEntry = false;
			} else {
				address.setResidenceNumber(Integer.parseInt(streetNum));
				validEntry = true;
			}
		} while (!validEntry);
		do {
			System.out.println("Enter the street name of the new subsciber's address:");
			String streetName = scan.nextLine();
			
			if (streetName.length() == 0 || streetName == null) {
				System.out.println("Please enter a streetName:");
				validEntry = false;
			} else {
				address.setStreetName(streetName);;
				validEntry = true;
			}
		} while (!validEntry);
		do {
			System.out.println("Enter the city name of the new subsciber's address:");
			String city = scan.nextLine();
			
			if (city.length() == 0 || city == null) {
				System.out.println("Please enter a city name:");
				validEntry = false;
			} else {
				address.setCity(city);
				validEntry = true;
			}
		} while (!validEntry);
		do {
			System.out.println("Enter the postal-code of the new subsciber's address:");
			String postalCode = scan.nextLine();
			
			if (!Address.validPostalCode(postalCode)) {
				System.out.println("Please enter a valid postal-code:");
				validEntry = false;
			} else {
				address.setPostalCode(postalCode);
				validEntry = true;
			}
			
			newSub.setAddress(address);
		} while (!validEntry);
		
		subCollection.addSubscriber(newSub);
		System.out.println(newSub.getName().getFirst() + " added!");
	}
	
	public static void editSubscriber() {
		System.out.println("Please enter a search term:");
		String searchTerm = scan.nextLine();
		List<Subscriber> results = subCollection.search(searchTerm);
		
		Subscriber editSub = null;
		
		if (results.size() == 0) {
			System.out.println("No matches found!");
		} else if (results.size() == 1) {
			editSub = results.get(0);
			System.out.println(editSub.getName().toString() + " found!");
		} else if (results.size() < 10) {
			System.out.println("Multiple subscribers found, select subscriber by number (type '0' to cancel):");
			List<Subscriber> searchResult = new ArrayList<>();
 			
			for (Subscriber s : results) {
				System.out.println((results.indexOf(s)+1) + ": " + s.toString());
				searchResult.add(s);
			}
			
			boolean validEntry = true;
			do {
				String userChoice = scan.nextLine();
				if (userChoice.equals("0")) {
					System.out.println("Cancelling...");
					validEntry = true;
					editSub = null;
				} else if (userChoice.matches("[0-9]+")) {
					editSub = searchResult.get(Integer.parseInt(userChoice)-1);
				} else {
					System.out.println("Error. Please select subscriber 1-9 (type '0' to cancel):");
					validEntry = false;
				}
			} while (!validEntry);
		} else {
			System.out.println("Too many results, please refine your search!");
		}
		
		boolean validEntry = true;
		if (editSub != null) {
			System.out.println("Change name (leave blank to keep current):");

			validEntry = true;
			do {
				String newName = scan.nextLine();
				
				if (newName.isEmpty()) {
					validEntry = true;
				} else if (!newName.replace(" ", "").matches("[a-zA-Z]+")) {
					System.out.println("Name must only be letters!");
					validEntry = false;
				} else if (!newName.contains(" ")) {
					System.out.println("Please enter a first and last name: ");
					validEntry = false;
				} else {
					editSub.setName(new Name(newName.split(" ")[0], newName.split(" ")[1]));
					validEntry = true;
				}
			} while (!validEntry);
			
			do {
				System.out.println("Change email (leave blank to keep current):");
				String email = scan.nextLine();
				
				if (email.isEmpty()) {
					validEntry = true;
				} else if (!email.contains("@") || !(email.contains(".com") || email.contains(".ca"))) {
					System.out.println("Please enter a valid email:");
					validEntry = false;
				} else {
					editSub.setEmail(email);
					validEntry = true;
				}
			} while (!validEntry);
			
			Address address = new Address();
			do {
				System.out.println("Change residence number (leave blank to keep current):");
				String streetNum = scan.nextLine();
				
				if (streetNum.isEmpty()) {
					validEntry = true;
					address.setResidenceNumber(editSub.getAddress().getResidenceNumber());
				} else if (streetNum.length() == 0 || streetNum.length() > 4) {
					System.out.println("Invalid size; please enter a street number from 1-4 digits:");
					validEntry = false;
				} else {
					address.setResidenceNumber(Integer.parseInt(streetNum));
					validEntry = true;
				}
			} while (!validEntry);
			do {
				System.out.println("Change street name (leave blank to keep current):");
				String streetName = scan.nextLine();
				
				if (streetName.isEmpty()) {
					validEntry = true;
					address.setStreetName(editSub.getAddress().getStreetName());
				} else {
					address.setStreetName(streetName);;
					validEntry = true;
				}
			} while (!validEntry);
			do {
				System.out.println("Change city (leave blank to keep current):");
				String city = scan.nextLine();
				
				if (city.isEmpty()) {
					validEntry = true;
					address.setCity(editSub.getAddress().getCity());
				} else {
					address.setCity(city);
					validEntry = true;
				}
			} while (!validEntry);
			do {
				System.out.println("Change postal-code (leave blank to keep current):");
				String postalCode = scan.nextLine();
				
				if (postalCode.isEmpty()) {
					validEntry = true;
					address.setPostalCode(editSub.getAddress().getPostalCode());
				} else if (!Address.validPostalCode(postalCode)) {
					System.out.println("Please enter a valid postal-code:");
					validEntry = false;
				} else {
					address.setPostalCode(postalCode);
					validEntry = true;
				}
				
				editSub.setAddress(address);
			} while (!validEntry);
			
			System.out.println("Changes saved!");
		}
	}
	
	public static void removeSubscriber() {
		System.out.println("Please enter a search term:");
		String searchTerm = scan.nextLine();
		List<Subscriber> results = subCollection.search(searchTerm);
		
		Subscriber removeSub = null;
		
		if (results.size() == 0) {
			System.out.println("No matches found!");
		} else if (results.size() == 1) {
			removeSub = results.get(0);
			System.out.println(removeSub.getName().toString() + " found!");
		} else if (results.size() < 10) {
			System.out.println("Multiple subscribers found, select subscriber by number (type '0' to cancel):");
			List<Subscriber> searchResult = new ArrayList<>();
 			
			for (Subscriber s : results) {
				System.out.println((results.indexOf(s)+1) + ": " + s.toString());
				searchResult.add(s);
			}
			
			boolean validEntry = true;
			do {
				String userChoice = scan.nextLine();
				if (userChoice.equals("0")) {
					System.out.println("Cancelling...");
					validEntry = true;
					removeSub = null;
				} else if (userChoice.matches("[0-9]+")) {
					removeSub = searchResult.get(Integer.parseInt(userChoice)-1);
				} else {
					System.out.println("Error. Please select subscriber 1-9 (type '0' to cancel):");
					validEntry = false;
				}
			} while (!validEntry);
		} else {
			System.out.println("Too many results, please refine your search!");
		}
		
		if (removeSub != null) {
			boolean validEntry = true;
			
			System.out.println("Are you sure you would like to delete " +
					removeSub.getName().getFirst() + "'s profile?");
			do {
				String deleteChoice = scan.nextLine();
				
				if (deleteChoice.equalsIgnoreCase("yes") || deleteChoice.equalsIgnoreCase("y") ||
						deleteChoice.equalsIgnoreCase("delete") || deleteChoice.equalsIgnoreCase("remove")) {
					subCollection.removeSubscriber(removeSub);
					System.out.println("Subscriber removed.");
					validEntry = true;
				} else if (deleteChoice.equalsIgnoreCase("no") || deleteChoice.equalsIgnoreCase("n") ||
						deleteChoice.equalsIgnoreCase("cancel")) {
					System.out.println("Cancelling...");
					validEntry = true;
				} else {
					System.out.println("Invalid choice: please type 'yes', 'no', or 'cancel':");
					validEntry = false;
				}
			} while (!validEntry);
		}
	}
	
	public static void saveFile() {
		// save the file
		subCollection.writeSubscriberCollection(fileName);
	}
}
