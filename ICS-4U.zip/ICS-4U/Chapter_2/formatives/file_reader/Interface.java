package formatives.file_reader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Interface {
	public static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("Welcome to the file reader. Please enter the file name you wish to read:");
		boolean validInput = true;
		
		do {
			String fileName = scan.nextLine();
			
			try {
				System.out.println("\nContents: \n/\n" + 
						indent(readFile(fileName)) + "/");
				validInput = true;
			} catch(FileNotFoundException e) {
				System.out.println("File not found!");
				validInput = false;
			} catch(FileEmptyException e) {
				System.out.println("File is empty!");
				validInput = false;
			} catch(InvalidFileExtensionException e) {
				System.out.println("Filename must end with '.txt'");
				validInput = false;
			} catch(IOException e) {
				e.printStackTrace();
				validInput = false;
			}
		} while (!validInput);
	}
	
	public static String indent(String input) {
		String[] outputs = input.split(System.getProperty("line.separator"));
		String output = "";
		for (String s : outputs) {
			output += ("\t" + s + "\n");
		}
		return output;
	}
	
	public static String readFile(String fileName) throws IOException {
		if (!fileName.endsWith(".txt")) {
			throw new InvalidFileExtensionException("Filename must end with '.txt'");
		}
		
		BufferedReader br = new BufferedReader(new FileReader(fileName));
	    StringBuilder sb = new StringBuilder();
	    String line = br.readLine();

	    while (line != null) {
	        sb.append(line);
	        sb.append(System.lineSeparator());
	        line = br.readLine();
	    }
	    
	    br.close();
	    
	    if (sb.length() == 0) {
	    	throw new FileEmptyException("File does not contain anything!");
	    }
	    return sb.toString();
	}
}

@SuppressWarnings("serial")
class FileEmptyException extends IOException {
	public FileEmptyException(String message) {
		super(message);
	}
}

@SuppressWarnings("serial")
class InvalidFileExtensionException extends IOException {
	public InvalidFileExtensionException(String message) {
		super(message);
	}
}
