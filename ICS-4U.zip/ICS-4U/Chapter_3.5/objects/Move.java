package objects;

public class Move {
	private Coordinate from;
	private Coordinate to;
	private double travelTime;
	
	public Move() {}
	
	public Move(Coordinate from, Coordinate to, double travelTime) {
		setFrom(from);
		setTo(to);
		setTravelTime(travelTime);
	}

	public Coordinate getFrom() {
		return from;
	}

	public void setFrom(Coordinate from) {
		this.from = from;
	}

	public Coordinate getTo() {
		return to;
	}

	public void setTo(Coordinate to) {
		this.to = to;
	}

	public double getTravelTime() {
		return travelTime;
	}

	public void setTravelTime(double travelTime) {
		this.travelTime = travelTime;
	}
}
