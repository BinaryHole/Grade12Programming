package objects;

public class Coordinate {
	private int xValue;
	private int yValue;
	
	public Coordinate(int xValue, int yValue) {
		this.setxValue(xValue);
		this.setyValue(yValue);
	}
	
	public int getxValue() {
		return xValue;
	}
	
	public int getxValueRaw() {
		return xValue-1;
	}

	public void setxValue(int xValue) {
		this.xValue = xValue;
	}
	
	public int getyValue() {
		return yValue;
	}
	
	public int getyValueRaw() {
		return yValue-1;
	}
	
	public void setyValue(int yValue) {
		this.yValue = yValue;
	}
	
	@Override
	public String toString() {
		return("(" + this.getxValue() + "," + this.getyValue() + ")");
	}
	
	public String toStringSimple() {
		return(this.getxValue() + " " + this.getyValue());
	}
	
	public static Coordinate parseCoordinate(String input) {
		input.replace(",", "");
		input.replace("(", "");
		input.replace(")", "");
		return parseCoordinateSimple(input);
	}
	
	public static Coordinate parseCoordinateSimple(String input) {
		int xValue = Integer.parseInt(input.split(" ")[0]);
		int yValue = Integer.parseInt(input.split(" ")[1]);
		return new Coordinate(xValue, yValue);
	}
}
