package objects;

import java.util.ArrayList;
import java.util.List;

public class Route {
	private List<Move> moves;
	private double travelTime = -1;

	public Route() {
		setMoves(new ArrayList<>());
	}

	public Route(List<Move> moves) {
		setMoves(moves);
	}

	public List<Move> getMoves() {
		return moves;
	}

	public void setMoves(List<Move> moves) {
		this.moves = moves;
	}

	public void addMove(Move move) {
		this.moves.add(move);
	}
	
	// this is used to delete the moves in the route
	public void clearRoute() {
		// reset the moves and travel time in this route
		setMoves(new ArrayList<>());
		this.travelTime = -1;
	}

	public boolean hasVisited(Tile tile) {
		// check each move to see if it has already been visited
		for (Move m : getMoves()) {
			// if the tile has been visited, return true
			if (m.getTo().equals(tile.getCoordinate())) {
				return true;
			}
		}
		
		// if the tile has not been visited, return false
		return false;
	}
	
	public boolean hasVisited(Coordinate coordinate) {
		// check each move to see if it has already been visited
		for (Move m : getMoves()) {
			// if the tile has been visited, return true
			if (m.getTo().getxValue() == coordinate.getxValue() && m.getTo().getyValue() == coordinate.getyValue()) {
				return true;
			}
		}
		
		// if the tile has not been visited, return false
		return false;
	}
	
	public double getTravelTime() {
		// if this is the first time calculating the travel time:
		if (this.travelTime == -1) {
			double travelTime = 0;
			
			// add the travel time from each move in the route
			for (Move m: getMoves()) {
				travelTime += m.getTravelTime();
			}
			
			return travelTime;
			
		// if the travel time has already been calculated:
		} else {
			return this.travelTime;
		}
	}
}
