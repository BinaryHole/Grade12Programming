package Interface;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import objects.Map;

public class Interface {
	public static String fileName = "routeCityInput.txt";
	
	public static void main(String[] args) {
		// create the city map from the external file
		Map cityMap = Map.parseMap(readFile(fileName));
		
		// show starting and destination points, map preview
		System.out.println(String.format("Determining best route from %s to %s...", 
				cityMap.getStartingPositon().toString(), cityMap.getDestinationPosition().toString()));
		System.out.println("\n" + cityMap.toString());
		
		// recursively find all possible routes
		cityMap.findPossibleRoutes();
		
		// display information
		System.out.println("There were " + cityMap.getRoutes().size() + " routes found."
				+ "\n\tThe fastest route took " + cityMap.getFastestRoute().getTravelTime() + " seconds.");
	}
	
	/**
	 * read a text file using a buffered reader and string builder
	 * @param fileName - the name of the file to read
	 * @return String - the composition of the file contents
	 */
	public static String readFile(String fileName) {
		String str = "";
		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    str = sb.toString();
		} catch (FileNotFoundException e) {
			System.out.println("File not found!");
			System.exit(0);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return str;
	}
}
